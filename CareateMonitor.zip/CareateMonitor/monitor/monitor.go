package monitor

import (
	"fmt"
	"net"
	"strconv"
	"time"

	"github.com/shirou/gopsutil/cpu"
	"github.com/shirou/gopsutil/disk"
	"github.com/shirou/gopsutil/mem"
)

//Monitor ：监控主体
type Monitor struct {
	IP            string
	ServerName    string
	messageChanel chan *MonitorMessage
}

func (monitor *Monitor) Write() {
	for {
		data := <-monitor.messageChanel
		fmt.Println(data)
	}
}

//InitMonitor ： 初始化
func InitMonitor() (monitor *Monitor) {
	var addr string
	if addrs, err := net.InterfaceAddrs(); err == nil {
		for _, address := range addrs {

			// 检查ip地址判断是否回环地址
			if ipnet, ok := address.(*net.IPNet); ok && !ipnet.IP.IsLoopback() {
				if ipnet.IP.To4() != nil {
					addr = ipnet.IP.String()
					break
				}
			}
		}
	}
	monitor = &Monitor{
		messageChanel: make(chan *MonitorMessage, 1000),
		IP:            addr,
		ServerName:    "测试serverName",
	}
	return
}

//MonitorLoop : 循环监控 间隔X秒
func (monitor *Monitor) MonitorLoop() {
	for {
		go monitor.getCPULoop()
		go monitor.getDiskLoop()
		go monitor.getMemLoop()
		time.Sleep(5 * time.Second)
	}
}

//GetMemLoop : 循环获取内存状态
func (monitor *Monitor) getMemLoop() {
	if m, err := mem.VirtualMemory(); err == nil {
		monitorMessage := &MonitorMessage{
			Key:         "RAM",
			Value:       strconv.FormatFloat(m.UsedPercent, 'f', 2, 64),
			Description: "内存",
			InDateTime:  GetTime(),
			ServerName:  monitor.ServerName,
			ServerIP:    monitor.IP,
		}
		monitor.messageChanel <- monitorMessage
	}
}

//GetDiskLoop : 循环获取内存状态
func (monitor *Monitor) getDiskLoop() {
	if d, err := disk.Usage("/"); err == nil {
		monitorMessage := &MonitorMessage{
			Key:         "DISK",
			Value:       strconv.FormatFloat(d.UsedPercent, 'f', 2, 64),
			Description: "硬盘",
			InDateTime:  GetTime(),
			ServerName:  monitor.ServerName,
			ServerIP:    monitor.IP,
		}
		monitor.messageChanel <- monitorMessage
	}
}

//GetCPULoop : 循环获取CPU状态
func (monitor *Monitor) getCPULoop() {
	if cp, err := cpu.Percent(time.Second, false); err == nil {
		monitorMessage := &MonitorMessage{
			Key:         "CPU",
			Value:       strconv.FormatFloat(cp[0], 'f', 2, 64),
			Description: "CPU",
			InDateTime:  GetTime(),
			ServerName:  monitor.ServerName,
			ServerIP:    monitor.IP,
		}
		monitor.messageChanel <- monitorMessage
	}
}

//GetTime : 获取当前时间字符串
func GetTime() (dataTimeStr string) {
	dataTimeStr = time.Now().Format("2006-01-02 15:04:05")
	return
}

//MonitorMessage : 监控消息
type MonitorMessage struct {
	ServerName  string
	ServerIP    string
	InDateTime  string
	Key         string
	Value       string
	Description string
	CreateTime  string
}

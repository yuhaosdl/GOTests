package main

import (
	"GOTests/CareateMonitor/monitor"
)

func main() {
	a := monitor.InitMonitor()
	a.MonitorLoop()
	a.Write()
	// m, _ := mem.VirtualMemory()
	// d, _ := disk.Usage("/")
	//n, _ := net.Connections("tcp")

	// established := 0
	// timewait := 0
	// closewait := 0
	// for _, item := range n {
	// 	if item.Status == "ESTABLISHED" {
	// 		established++
	// 	}
	// 	if item.Status == "TIME_WAIT" {
	// 		timewait++
	// 	}
	// 	if item.Status == "CLOSE_WAIT" {
	// 		closewait++
	// 	}
	// }
	// almost every return value is a struct
	// fmt.Printf("Total: %v, Free:%v, UsedPercent:%f%%\n", m.Total, m.Free, m.UsedPercent)

	// // convert to JSON. String() is also implemented
	// fmt.Println(d)
	// fmt.Println(n)
	// fmt.Println(established)
	// fmt.Println(timewait)
	// fmt.Println(closewait)
}
